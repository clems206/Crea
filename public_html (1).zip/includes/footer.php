    <footer class="bg-secondary border-t border-custom mt-16">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <h3 class="text-lg font-semibold brand-text mb-3">CréaMod3D</h3>
                    <p class="text-sm text-muted">Solutions créatives d'impression 3D personnalisées. De l'idée à la réalité.</p>
                     <img src="assets/images/logo.png" alt="Logo CréaMod3D Footer" class="h-16 w-auto mt-4" onerror="this.style.display='none';">
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-main mb-3">Liens Rapides</h3>
                    <ul class="space-y-2">
                        <li><a href="#accueil" @click.prevent="navigate('accueil')" class="text-sm text-muted hover:text-brand-green">Accueil</a></li>
                        <li><a href="#produits" @click.prevent="navigate('produits')" class="text-sm text-muted hover:text-brand-green">Produits</a></li>
                        <li><a href="#devis" @click.prevent="navigate('devis')" class="text-sm text-muted hover:text-brand-green">Demande de Devis</a></li>
                        <li><a href="#contact" @click.prevent="navigate('contact')" class="text-sm text-muted hover:text-brand-green">Contact</a></li>
                        </ul>
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-main mb-3">Contact & Réseaux</h3>
                    <p class="text-sm text-muted mb-1"><i class="fas fa-envelope mr-2 brand-accent"></i> <a href="mailto:contact@creamod3d.fr" class="hover:text-brand-green">contact@creamod3d.fr</a></p>
                    <div class="flex space-x-4 mt-4">
                        <a href="https://www.facebook.com/profile.php?id=61576107364762" target="_blank" rel="noopener noreferrer" aria-label="Facebook CréaMod3D" class="text-muted hover:text-brand-green text-xl">
                            <i class="fab fa-facebook-square"></i>
                        </a>
                        <a href="https://www.instagram.com/creamod3d.fr/" target="_blank" rel="noopener noreferrer" aria-label="Instagram CréaMod3D" class="text-muted hover:text-brand-green text-xl">
                            <i class="fab fa-instagram-square"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="mt-8 pt-8 border-t border-custom text-center text-sm text-muted">
                <p>© <span x-text="new Date().getFullYear()"></span> CréaMod3D. Tous droits réservés.</p>
                <p class="text-xs mt-1">Site web conçu avec <i class="fas fa-heart text-red-500"></i>.</p>
                </div>
        </div>
    </footer>
    
    <script>
        // Alpine.js component for the quote form
        function quoteForm() {
            return {
                formData: {
                    nom: '',
                    prenom: '',
                    email: '',
                    telephone: '',
                    typeProjet: '',
                    textePersonnalise: '',
                    couleurContour: 'noir',
                    eclairage: 'blanc_chaud',
                    optionRgb: 'aucune',
                    descriptionProjet: '',
                    fileName: ''
                },
                estimatedPrice: 0,
                charCountMessage: '0/13 caractères',
                textError: '',
                
                init() {
                    if (!Alpine.store('quoteFormStore')) {
                        Alpine.store('quoteFormStore', {
                            submissionMessage: '',
                            submissionStatus: ''
                        });
                    }
                    this.$watch('formData.textePersonnalise', (newValue) => {
                        this.validateText();
                        if (this.formData.typeProjet === 'prenom_lumineux' || this.formData.typeProjet === 'logo_lumineux') {
                           this.calculatePrice();
                        }
                    });
                    this.$watch('formData.typeProjet', () => this.resetConditionalFieldsAndPrice());
                    this.$watch('formData.eclairage', () => {
                        if (this.formData.eclairage !== 'rgb') this.formData.optionRgb = 'aucune';
                        this.calculatePrice();
                    });
                },
                
                handleFileUpload(event) {
                    const file = event.target.files[0];
                    if (file) {
                        this.formData.fileName = file.name;
                        if (file.size > 5 * 1024 * 1024) { 
                            Alpine.store('quoteFormStore').submissionMessage = 'Le fichier est trop volumineux (max 5MB).';
                            Alpine.store('quoteFormStore').submissionStatus = 'error';
                            event.target.value = null; 
                            this.formData.fileName = '';
                            return;
                        } else {
                             Alpine.store('quoteFormStore').submissionMessage = ''; 
                             Alpine.store('quoteFormStore').submissionStatus = '';
                        }
                    } else {
                        this.formData.fileName = '';
                    }
                },

                validateText() {
                    const text = this.formData.textePersonnalise;
                    const maxLength = 13;
                    const regex = /^[a-zA-Z0-9\s]*$/;
                    this.charCountMessage = `${text.length}/${maxLength} caractères`;
                    if (!regex.test(text)) {
                        this.textError = 'Caractères spéciaux non autorisés.';
                    } else {
                        this.textError = '';
                    }
                     if (text.length > maxLength) {
                        this.formData.textePersonnalise = text.substring(0, maxLength);
                    }
                },
                
                resetConditionalFieldsAndPrice() {
                    if (this.formData.typeProjet !== 'prenom_lumineux' && this.formData.typeProjet !== 'logo_lumineux') {
                        this.formData.textePersonnalise = '';
                        this.formData.couleurContour = 'noir';
                        this.formData.eclairage = 'blanc_chaud';
                        this.formData.optionRgb = 'aucune';
                        this.estimatedPrice = 0;
                        this.charCountMessage = '0/13 caractères';
                        this.textError = '';
                    }
                    this.calculatePrice();
                },

                calculatePrice() {
                    if (this.formData.typeProjet !== 'prenom_lumineux' && this.formData.typeProjet !== 'logo_lumineux') {
                        this.estimatedPrice = 0;
                        return;
                    }
                    let price = 0;
                    const text = this.formData.textePersonnalise.replace(/\s/g, ''); 
                    const numChars = text.length;
                    if (numChars > 0) {
                        price = 39; 
                        if (numChars > 3) {
                            price += (numChars - 3) * 5; 
                        }
                    } else {
                         this.estimatedPrice = 0; 
                         return;
                    }
                    if (this.formData.eclairage === 'rgb') {
                        if (this.formData.optionRgb === 'bluetooth') price += 5;
                        else if (this.formData.optionRgb === 'wifi') price += 8;
                    }
                    this.estimatedPrice = price;
                },

                clientSideValidationBeforeSubmit(event) {
                    Alpine.store('quoteFormStore').submissionMessage = '';
                    Alpine.store('quoteFormStore').submissionStatus = '';
                    let isValid = true;
                    if (!this.formData.nom || !this.formData.prenom || !this.formData.email || !this.formData.typeProjet || !this.formData.descriptionProjet) {
                        Alpine.store('quoteFormStore').submissionMessage = 'Veuillez remplir tous les champs obligatoires.';
                        Alpine.store('quoteFormStore').submissionStatus = 'error';
                        isValid = false;
                    }
                    if ((this.formData.typeProjet === 'prenom_lumineux' || this.formData.typeProjet === 'logo_lumineux') && !this.formData.textePersonnalise) {
                        Alpine.store('quoteFormStore').submissionMessage = 'Veuillez entrer le texte personnalisé pour le prénom/logo lumineux.';
                        Alpine.store('quoteFormStore').submissionStatus = 'error';
                         isValid = false;
                    }
                     if (this.textError) {
                        Alpine.store('quoteFormStore').submissionMessage = 'Veuillez corriger les erreurs dans le champ "Texte personnalisé".';
                        Alpine.store('quoteFormStore').submissionStatus = 'error';
                        isValid = false;
                    }
                    if (!isValid) {
                        event.preventDefault(); 
                    }
                }
            }
        }
        
        function contactForm() {
            return {
                contactData: {
                    nom: '',
                    email: '',
                    sujet: '',
                    message: ''
                },
                init() {
                    if (!Alpine.store('contactFormStore')) {
                        Alpine.store('contactFormStore', {
                            contactSubmissionMessage: '',
                            contactSubmissionStatus: ''
                        });
                    }
                },
                clientSideContactValidation(event) {
                    Alpine.store('contactFormStore').contactSubmissionMessage = '';
                    Alpine.store('contactFormStore').contactSubmissionStatus = '';
                    let isValid = true;
                    if (!this.contactData.nom || !this.contactData.email || !this.contactData.sujet || !this.contactData.message) {
                        Alpine.store('contactFormStore').contactSubmissionMessage = 'Veuillez remplir tous les champs.';
                        Alpine.store('contactFormStore').contactSubmissionStatus = 'error';
                        isValid = false;
                    }
                    if (!isValid) {
                        event.preventDefault();
                    }
                }
            }
        }
    </script>

</body>
</html>
