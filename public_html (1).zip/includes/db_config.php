<?php
// includes/db_config.php

// --- Configuration de la Base de Données ---

// Environnement de Développement/Production (à adapter)
// Pour la production, il est FORTEMENT recommandé d'utiliser des variables d'environnement
// ou un fichier de configuration en dehors du répertoire web racine pour stocker ces informations sensibles.
define('DB_HOST', 'localhost'); // Ou l'hôte fourni par Hostinger (souvent 'localhost')
define('DB_NAME', 'u923439069_creamod3d');
define('DB_USER', 'u923439069_clems206');
define('DB_PASS', 'Z2&ceAm5'); // **ATTENTION : Mot de passe sensible.** Changez-le pour la production.

// Options PDO (facultatif, mais recommandé pour la robustesse)
define('PDO_OPTIONS', [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Gérer les erreurs comme des exceptions
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Récupérer les résultats sous forme de tableaux associatifs
    PDO::ATTR_EMULATE_PREPARES   => false,                  // Désactiver l'émulation des requêtes préparées pour une vraie préparation
]);

/**
 * Fonction pour établir une connexion PDO à la base de données.
 * * @return PDO|null Retourne un objet PDO en cas de succès, ou null en cas d'échec.
 */
function connect_db() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, PDO_OPTIONS);
        return $pdo;
    } catch (PDOException $e) {
        // En mode développement, vous pouvez afficher l'erreur.
        // En production, logguez l'erreur et affichez un message générique à l'utilisateur.
        // error_log("Erreur de connexion à la base de données : " . $e->getMessage());
        // die("Erreur de connexion à la base de données. Veuillez réessayer plus tard."); 
        // Ou retournez null et gérez-le dans le script appelant.
        return null; 
    }
}

/*
// Exemple d'utilisation dans un autre script PHP (par exemple, submit_devis.php) :

require_once 'includes/db_config.php'; // Assurez-vous que le chemin est correct

$pdo = connect_db();

if ($pdo) {
    // Votre code pour interagir avec la base de données...
    // Exemple : $stmt = $pdo->query("SELECT * FROM votre_table");
    // while ($row = $stmt->fetch()) {
    //     print_r($row);
    // }
} else {
    // Gérer l'échec de la connexion
    echo "Impossible d'établir une connexion à la base de données.";
}

// N'oubliez pas de fermer la connexion si vous ne l'utilisez plus (bien que PDO la ferme souvent automatiquement à la fin du script)
// $pdo = null; 

*/

?>
