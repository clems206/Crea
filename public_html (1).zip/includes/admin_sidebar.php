<?php
// includes/admin_sidebar.php
// Ce fichier contient la barre latérale de navigation pour l'interface d'administration.
// Il est destiné à être inclus dans les pages d'administration comme admin_dashboard.php, admin_manage_products.php, etc.

// Déterminer la page active pour le style du lien
$current_page_script = basename($_SERVER['PHP_SELF']);

// S'assurer que $nombre_devis_en_attente est défini, même si c'est à 0.
// Cette variable devrait être calculée dans la page principale qui inclut cette sidebar,
// mais nous mettons une valeur par défaut pour éviter les erreurs si elle n'est pas passée.
if (!isset($nombre_devis_en_attente)) {
    // Tenter de la recalculer si $pdo est disponible et n'a pas été fait avant
    if (isset($pdo) && $pdo instanceof PDO) {
        try {
            $stmt_sidebar_count = $pdo->query("SELECT COUNT(*) FROM demandes_devis WHERE statut = 'En attente'");
            $nombre_devis_en_attente = $stmt_sidebar_count->fetchColumn();
        } catch (PDOException $e) {
            error_log("Erreur sidebar (calcul devis en attente): " . $e->getMessage());
            $nombre_devis_en_attente = 0;
        }
    } else {
        $nombre_devis_en_attente = 0;
    }
}
?>
<aside class="admin-sidebar w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out print:hidden">
    <a href="admin_dashboard.php" class="flex items-center space-x-3 px-4">
        <img src="assets/images/logo.png" alt="Logo CréaMod3D" class="h-10 w-auto" onerror="this.style.display='none';">
        <span class="text-2xl font-bold text-white">CréaMod3D</span>
    </a>

    <nav class="space-y-1">
        <a href="admin_dashboard.php" class="flex items-center space-x-3 rounded-md px-3 py-2 text-sm font-medium <?php echo ($current_page_script == 'admin_dashboard.php') ? 'active' : ''; ?>">
            <i class="fas fa-tachometer-alt fa-fw mr-2"></i>
            Tableau de bord
        </a>
        <a href="admin_manage_quotes.php" class="flex items-center space-x-3 rounded-md px-3 py-2 text-sm font-medium <?php echo ($current_page_script == 'admin_manage_quotes.php') ? 'active' : ''; ?>">
            <i class="fas fa-file-invoice-dollar fa-fw mr-2"></i>
            Gestion des Devis
            <?php if ($nombre_devis_en_attente > 0): ?>
                <span class="ml-auto bg-yellow-500 text-gray-800 text-xs font-semibold px-2 py-0.5 rounded-full"><?php echo $nombre_devis_en_attente; ?></span>
            <?php endif; ?>
        </a>
        <a href="admin_manage_products.php" class="flex items-center space-x-3 rounded-md px-3 py-2 text-sm font-medium <?php echo ($current_page_script == 'admin_manage_products.php') ? 'active' : ''; ?>">
            <i class="fas fa-cubes fa-fw mr-2"></i>
            Gestion des Produits
        </a>
        <a href="admin_manage_contacts.php" class="flex items-center space-x-3 rounded-md px-3 py-2 text-sm font-medium <?php echo ($current_page_script == 'admin_manage_contacts.php') ? 'active' : ''; ?>">
            <i class="fas fa-envelope-open-text fa-fw mr-2"></i>
            Messages de Contact
        </a>
        <a href="admin_settings.php" class="flex items-center space-x-3 rounded-md px-3 py-2 text-sm font-medium <?php echo ($current_page_script == 'admin_settings.php') ? 'active' : ''; ?>">
            <i class="fas fa-cogs fa-fw mr-2"></i>
            Paramètres
        </a>
    </nav>
    
    <div class="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-700">
         <a href="index.php" target="_blank" class="flex items-center space-x-3 rounded-md px-3 py-2 text-sm font-medium text-gray-400 hover:bg-gray-700 hover:text-white">
            <i class="fas fa-globe fa-fw mr-2"></i>
            Voir le site public
        </a>
        <a href="admin_logout.php" class="flex items-center space-x-3 rounded-md px-3 py-2 text-sm font-medium text-gray-400 hover:bg-red-600 hover:text-white mt-2">
            <i class="fas fa-sign-out-alt fa-fw mr-2"></i>
            Déconnexion
        </a>
    </div>
</aside>
