<?php
// includes/header.php

// Démarrer la session si ce n'est pas déjà fait (utile si vous l'utilisez ailleurs)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db_config.php'; // Utiliser __DIR__ pour un chemin plus robuste

// --- Vérification du Mode Maintenance ---
$pdo_maintenance_check = connect_db();
$maintenance_mode_active = false;
// Vérifie si un admin est connecté POUR CETTE VÉRIFICATION SPÉCIFIQUE (pour bypass)
$is_admin_logged_in_for_maintenance_check = (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true);


if ($pdo_maintenance_check) {
    try {
        $stmt_maintenance = $pdo_maintenance_check->prepare("SELECT setting_value FROM site_settings WHERE setting_name = 'maintenance_mode'");
        $stmt_maintenance->execute();
        $maintenance_setting = $stmt_maintenance->fetchColumn();
        if ($maintenance_setting === '1') {
            $maintenance_mode_active = true;
        }
    } catch (PDOException $e) {
        error_log("Erreur header (vérification maintenance): " . $e->getMessage());
        // En cas d'erreur BDD, on pourrait décider de ne pas activer le mode maintenance
        // ou au contraire, de l'activer par sécurité. Ici, on le laisse désactivé.
    }
}

// Déterminer si la page actuelle est une page d'administration ou la page de maintenance elle-même
$current_script_path = $_SERVER['PHP_SELF'];
$is_admin_page_or_maintenance = false;
$admin_related_pages = [
    '/admin_login.php', 
    '/admin_dashboard.php', 
    '/admin_manage_quotes.php', 
    '/admin_manage_products.php', 
    '/admin_manage_contacts.php', 
    '/admin_settings.php', 
    '/admin_logout.php',
    '/maintenance.php' // Exclure la page de maintenance elle-même de la redirection
];

foreach ($admin_related_pages as $page_path) {
    // Vérifie si le chemin du script actuel se termine par un des chemins admin/maintenance
    // Cela évite les faux positifs si un chemin public contient une partie d'un chemin admin
    if (substr_compare($current_script_path, $page_path, -strlen($page_path)) === 0) {
        $is_admin_page_or_maintenance = true;
        break;
    }
}


if ($maintenance_mode_active && !$is_admin_logged_in_for_maintenance_check && !$is_admin_page_or_maintenance) {
    header('HTTP/1.1 503 Service Temporarily Unavailable');
    header('Retry-After: 3600'); 
    
    // Construction dynamique du chemin de base du site
    $base_uri_path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    if ($base_uri_path === DIRECTORY_SEPARATOR || $base_uri_path === '.') { // Si à la racine, dirname peut retourner '.' ou '/'
        $base_uri_path = '';
    }
    
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    // Assurez-vous que maintenance.php est à la racine de votre installation (par rapport à index.php)
    $maintenance_page_url = $protocol . $host . $base_uri_path . '/maintenance.php'; 

    header('Location: ' . $maintenance_page_url); 
    exit; 
}

if (!isset($page_title)) {
    $page_title = 'CréaMod3D - Création et Impression 3D';
}
?>
<!DOCTYPE html>
<html lang="fr" class="light"> <head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <link rel="stylesheet" href="assets/css/style.css"> 
    
    <link rel="icon" href="assets/images/logo.png" type="image/png"> 
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="bg-primary text-main" x-data="{ 
    currentPage: 'accueil',
    isMobileMenuOpen: false,
    theme: localStorage.getItem('theme') || 'light',
    pageTitle: document.title, 

    toggleTheme() {
        this.theme = this.theme === 'light' ? 'dark' : 'light';
        localStorage.setItem('theme', this.theme);
        document.documentElement.className = this.theme;
    },
    init() {
        document.documentElement.className = this.theme; 
        this.navigateToPageFromHash(); 
        
        window.addEventListener('update-title', (event) => {
            if (event.detail && event.detail.title) {
                this.pageTitle = event.detail.title;
                document.title = this.pageTitle;
            }
        });
        this.updateTitleForCurrentPage(this.currentPage);
    },
    updateTitleForCurrentPage(page) {
        let newTitle = 'CréaMod3D'; 
        const pageSpecificTitles = {
            'accueil': 'CréaMod3D - Accueil - Impression 3D Personnalisée',
            'produits': 'Nos Produits - CréaMod3D',
            'devis': 'Demande de Devis - CréaMod3D',
            'contact': 'Contactez-Nous - CréaMod3D'
        };
        
        if (pageSpecificTitles[page]) {
            newTitle = pageSpecificTitles[page];
        } else if (page === 'admin-dashboard' && window.location.pathname.includes('admin_')) {
            return; 
        } else if (window.location.pathname.includes('produit_detail.php')) {
            return;
        }

        if (document.title !== newTitle) {
            this.pageTitle = newTitle;
            document.title = this.pageTitle;
        }
    },
    navigateToPageFromHash() {
        const hash = window.location.hash.substring(1) || 'accueil';
        const validPages = ['accueil', 'produits', 'devis', 'contact', 'admin-dashboard']; 
        
        if (validPages.includes(hash)) {
            this.currentPage = hash;
        } else {
            this.currentPage = 'accueil'; 
            if(window.location.hash && window.location.hash !== '#') { 
                 window.location.hash = 'accueil'; 
            }
        }
        this.setActiveLink(); 
        this.updateTitleForCurrentPage(this.currentPage);

        const urlParams = new URLSearchParams(window.location.search);
        const quoteStatus = urlParams.get('quote_status');
        if (quoteStatus && this.currentPage === 'devis') {
            const quoteMessage = urlParams.get('message');
            if (Alpine.store('quoteFormStore')) { 
                 Alpine.store('quoteFormStore').submissionStatus = quoteStatus;
                 Alpine.store('quoteFormStore').submissionMessage = decodeURIComponent(quoteMessage);
            }
            window.history.replaceState({}, document.title, window.location.pathname + '#devis');
        }
        const contactStatus = urlParams.get('contact_status');
         if (contactStatus && this.currentPage === 'contact') {
            const contactMessage = urlParams.get('message');
            if (Alpine.store('contactFormStore')) {
                Alpine.store('contactFormStore').contactSubmissionStatus = contactStatus;
                Alpine.store('contactFormStore').contactSubmissionMessage = decodeURIComponent(contactMessage);
            }
            window.history.replaceState({}, document.title, window.location.pathname + '#contact');
        }
    },
    navigate(page) {
        this.currentPage = page;
        window.location.hash = page;
        this.isMobileMenuOpen = false;
        this.setActiveLink();
        this.updateTitleForCurrentPage(page);
        window.scrollTo(0, 0);
    },
    setActiveLink() {
        document.querySelectorAll('header nav a').forEach(link => { 
            link.classList.remove('active-nav-link');
            const linkHash = link.getAttribute('href').substring(link.getAttribute('href').indexOf('#'));
            if (linkHash === '#' + this.currentPage) {
                link.classList.add('active-nav-link');
            }
        });
    }
}" x-init="init()">

    <?php 
        include __DIR__ . '/menu.php'; 
    ?>
