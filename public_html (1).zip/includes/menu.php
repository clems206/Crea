<?php
// includes/menu.php
// Ce fichier contient la structure du menu de navigation et le sélecteur de thème.
// Il est destiné à être inclus dans header.php.
?>
<header class="bg-secondary shadow-md sticky top-0 z-50 border-b border-custom">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
            <a href="#accueil" @click.prevent="navigate('accueil')" class="flex items-center space-x-2">
                <img src="assets/images/logo.png" alt="Logo CréaMod3D" class="h-12 w-auto" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                <div style="display:none;" class="header-logo-text">
                    <span>CRÉA</span><span class="brand-accent">MOD3D</span>
                </div>
            </a>

            <nav class="hidden md:flex space-x-6 items-center">
                <a href="#accueil" @click.prevent="navigate('accueil')" class="hover:text-brand-green px-3 py-2 rounded-md text-sm font-medium">Accueil</a>
                <a href="#produits" @click.prevent="navigate('produits')" class="hover:text-brand-green px-3 py-2 rounded-md text-sm font-medium">Produits</a>
                <a href="#devis" @click.prevent="navigate('devis')" class="hover:text-brand-green px-3 py-2 rounded-md text-sm font-medium">Devis</a>
                <a href="#contact" @click.prevent="navigate('contact')" class="hover:text-brand-green px-3 py-2 rounded-md text-sm font-medium">Contact</a>
                <?php /* Lien Admin supprimé
                <a href="#admin-dashboard" @click.prevent="navigate('admin-dashboard')" class="text-xs hover:text-brand-green px-3 py-2 rounded-md text-sm font-medium text-muted">Admin</a>
                */ ?>
            </nav>

            <button @click="toggleTheme()" class="p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-green" :aria-label="theme === 'light' ? 'Passer au thème sombre' : 'Passer au thème clair'">
                <i x-show="theme === 'light'" class="fas fa-moon text-xl text-gray-600"></i>
                <i x-show="theme === 'dark'" class="fas fa-sun text-xl text-yellow-400"></i>
            </button>

            <div class="md:hidden flex items-center">
                <button @click="isMobileMenuOpen = !isMobileMenuOpen" class="p-2 rounded-md text-muted hover:text-brand-green focus:outline-none">
                    <span class="sr-only">Ouvrir le menu principal</span>
                    <i class="fas fa-bars text-xl"></i>
                </button>
            </div>
        </div>
    </div>

    <div x-show="isMobileMenuOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 translate-y-1"
         x-transition:enter-end="opacity-100 translate-y-0"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 translate-y-0"
         x-transition:leave-end="opacity-0 translate-y-1"
         class="md:hidden bg-secondary border-t border-custom"
         @click.away="isMobileMenuOpen = false" 
         x-cloak>
        <nav class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#accueil" @click.prevent="navigate('accueil')" class="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-200 dark:hover:bg-gray-700">Accueil</a>
            <a href="#produits" @click.prevent="navigate('produits')" class="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-200 dark:hover:bg-gray-700">Produits</a>
            <a href="#devis" @click.prevent="navigate('devis')" class="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-200 dark:hover:bg-gray-700">Devis</a>
            <a href="#contact" @click.prevent="navigate('contact')" class="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-200 dark:hover:bg-gray-700">Contact</a>
            <?php /* Lien Admin supprimé
            <a href="#admin-dashboard" @click.prevent="navigate('admin-dashboard')" class="block px-3 py-2 rounded-md text-base font-medium text-muted hover:bg-gray-200 dark:hover:bg-gray-700">Admin</a>
            */ ?>
        </nav>
    </div>
</header>
