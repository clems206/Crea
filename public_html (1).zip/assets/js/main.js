// assets/js/main.js

// Alpine.js component for the quote form
function quoteForm() {
    return {
        formData: {
            nom: '',
            prenom: '',
            email: '',
            telephone: '',
            typeProjet: '',
            textePersonnalise: '',
            couleurContour: 'noir',
            eclairage: 'blanc_chaud',
            optionRgb: 'aucune',
            descriptionProjet: '',
            fileName: '' // Store the name of the selected file
        },
        estimatedPrice: 0,
        charCountMessage: '0/13 caractères',
        textError: '',
        // isLoading and submission messages are handled by Alpine store, 
        // which can be updated by URL params from PHP after form submission.
        
        init() {
            // Initialize the Alpine store for quote form messages if not already present
            if (!Alpine.store('quoteFormStore')) {
                Alpine.store('quoteFormStore', {
                    submissionMessage: '',
                    submissionStatus: '' // 'success' or 'error'
                });
            }

            // Watch for changes in textePersonnalise to validate and recalculate price
            this.$watch('formData.textePersonnalise', (newValue) => {
                this.validateText();
                if (this.formData.typeProjet === 'prenom_lumineux' || this.formData.typeProjet === 'logo_lumineux') {
                   this.calculatePrice();
                }
            });

            // Watch for changes in typeProjet to reset conditional fields and price
            this.$watch('formData.typeProjet', () => this.resetConditionalFieldsAndPrice());

            // Watch for changes in eclairage to reset RGB option and recalculate price
            this.$watch('formData.eclairage', () => {
                if (this.formData.eclairage !== 'rgb') {
                    this.formData.optionRgb = 'aucune';
                }
                this.calculatePrice();
            });
        },
        
        handleFileUpload(event) {
            const file = event.target.files[0];
            if (file) {
                this.formData.fileName = file.name;
                // Client-side validation for file size (example: max 5MB)
                if (file.size > 5 * 1024 * 1024) { 
                    Alpine.store('quoteFormStore').submissionMessage = 'Le fichier est trop volumineux (max 5MB). Veuillez sélectionner un fichier plus petit.';
                    Alpine.store('quoteFormStore').submissionStatus = 'error';
                    event.target.value = null; // Clear the selected file from input
                    this.formData.fileName = ''; // Reset fileName
                    return;
                } else {
                     // Clear any previous file error message if a new valid file is selected
                     if (Alpine.store('quoteFormStore').submissionMessage.includes('fichier')) {
                        Alpine.store('quoteFormStore').submissionMessage = ''; 
                        Alpine.store('quoteFormStore').submissionStatus = '';
                     }
                }
            } else {
                this.formData.fileName = '';
            }
        },

        validateText() {
            const text = this.formData.textePersonnalise;
            const maxLength = 13;
            // Regex to allow letters (including accented ones for French), numbers, and spaces
            const regex = /^[a-zA-Z0-9\sÀ-ÿ]*$/; 
            
            this.charCountMessage = `${text.length}/${maxLength} caractères`;

            if (!regex.test(text)) {
                this.textError = 'Caractères spéciaux non autorisés (lettres, chiffres et espaces uniquement).';
            } else {
                this.textError = '';
            }
            // Ensure text does not exceed maxLength (already handled by input maxlength attribute, but good for consistency)
             if (text.length > maxLength) {
                this.formData.textePersonnalise = text.substring(0, maxLength);
            }
        },
        
        resetConditionalFieldsAndPrice() {
            // Reset fields specific to "Prénom Lumineux" or "Logo Lumineux"
            // when a different project type is selected.
            if (this.formData.typeProjet !== 'prenom_lumineux' && this.formData.typeProjet !== 'logo_lumineux') {
                this.formData.textePersonnalise = '';
                this.formData.couleurContour = 'noir';
                this.formData.eclairage = 'blanc_chaud';
                this.formData.optionRgb = 'aucune';
                this.estimatedPrice = 0;
                this.charCountMessage = '0/13 caractères';
                this.textError = '';
            }
            this.calculatePrice(); // Recalculate, which will set price to 0 if not applicable
        },

        calculatePrice() {
            if (this.formData.typeProjet !== 'prenom_lumineux' && this.formData.typeProjet !== 'logo_lumineux') {
                this.estimatedPrice = 0;
                return;
            }

            let price = 0;
            // Remove spaces for character count, but allow them in the input
            const textForCount = this.formData.textePersonnalise.replace(/\s/g, ''); 
            const numChars = textForCount.length;

            if (numChars > 0) {
                price = 39.00; // Base price for up to 3 chars
                if (numChars > 3) {
                    price += (numChars - 3) * 5.00; // 5€ per additional char
                }
            } else {
                 this.estimatedPrice = 0; // No text, no price
                 return;
            }

            if (this.formData.eclairage === 'rgb') {
                if (this.formData.optionRgb === 'bluetooth') {
                    price += 5.00; // Bluetooth supplement
                } else if (this.formData.optionRgb === 'wifi') {
                    price += 8.00; // Wifi supplement
                }
            }
            this.estimatedPrice = price;
        },

        clientSideValidationBeforeSubmit(event) {
            // This function is called on form submit (@submit="clientSideValidationBeforeSubmit")
            // It performs client-side checks. If any fail, it prevents form submission.
            // The actual submission to PHP happens if all checks pass.

            // Clear previous messages from the Alpine store
            Alpine.store('quoteFormStore').submissionMessage = '';
            Alpine.store('quoteFormStore').submissionStatus = '';

            let isValid = true;
            let errorMessages = [];

            if (!this.formData.nom.trim()) errorMessages.push('Le nom est requis.');
            if (!this.formData.prenom.trim()) errorMessages.push('Le prénom est requis.');
            if (!this.formData.email.trim()) {
                errorMessages.push("L'adresse Email est requise.");
            } else if (!/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/.test(this.formData.email)) {
                errorMessages.push("Le format de l'adresse Email est invalide.");
            }
            if (!this.formData.typeProjet) errorMessages.push('Le type de projet est requis.');
            if (!this.formData.descriptionProjet.trim()) errorMessages.push('La description de votre projet est requise.');

            if ((this.formData.typeProjet === 'prenom_lumineux' || this.formData.typeProjet === 'logo_lumineux')) {
                if (!this.formData.textePersonnalise.trim()) {
                    errorMessages.push('Le texte personnalisé est requis pour ce type de projet.');
                }
                if (this.textError) { // Check if there's an existing error from validateText()
                    errorMessages.push(this.textError);
                }
            }
            
            // Check file size again if a file is selected (as a fallback)
            const fileInput = document.getElementById('file_upload');
            if (fileInput && fileInput.files && fileInput.files[0]) {
                if (fileInput.files[0].size > 5 * 1024 * 1024) {
                     errorMessages.push('Le fichier est trop volumineux (max 5MB).');
                }
            }


            if (errorMessages.length > 0) {
                Alpine.store('quoteFormStore').submissionMessage = "Veuillez corriger les erreurs suivantes :<br><ul><li>" + errorMessages.join("</li><li>") + "</li></ul>";
                Alpine.store('quoteFormStore').submissionStatus = 'error';
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault(); // Stop form submission if client-side validation fails
            }
            // If isValid is true, the form will submit to the PHP action attribute
        }
    }
}

// Alpine.js component for the contact form
function contactForm() {
    return {
        contactData: {
            nom: '',
            email: '',
            sujet: '',
            message: ''
        },
        // isLoading and submission messages are handled by Alpine store, 
        // which can be updated by URL params from PHP after form submission.

        init() {
            // Initialize the Alpine store for contact form messages if not already present
            if (!Alpine.store('contactFormStore')) {
                Alpine.store('contactFormStore', {
                    contactSubmissionMessage: '',
                    contactSubmissionStatus: '' // 'success' or 'error'
                });
            }
        },

        clientSideContactValidation(event) {
            // This function is called on form submit (@submit="clientSideContactValidation")
            Alpine.store('contactFormStore').contactSubmissionMessage = '';
            Alpine.store('contactFormStore').contactSubmissionStatus = '';
            
            let isValid = true;
            let errorMessages = [];

            if (!this.contactData.nom.trim()) errorMessages.push('Le nom est requis.');
            if (!this.contactData.email.trim()) {
                 errorMessages.push("L'Email est requis.");
            } else if (!/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/.test(this.contactData.email)) {
                errorMessages.push("Le format de l'adresse Email est invalide.");
            }
            if (!this.contactData.sujet.trim()) errorMessages.push('Le sujet est requis.');
            if (!this.contactData.message.trim()) errorMessages.push('Le message ne peut pas être vide.');

            if (errorMessages.length > 0) {
                Alpine.store('contactFormStore').contactSubmissionMessage = "Veuillez corriger les erreurs suivantes :<br><ul><li>" + errorMessages.join("</li><li>") + "</li></ul>";
                Alpine.store('contactFormStore').contactSubmissionStatus = 'error';
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault(); // Stop form submission
            }
            // If isValid is true, the form will submit to the PHP action attribute
        }
    }
}

// Vous pourriez ajouter d'autres fonctions JavaScript globales ici si nécessaire.
// Par exemple, pour initialiser des bibliothèques ou des écouteurs d'événements
// document.addEventListener('DOMContentLoaded', () => {
//    console.log('Le DOM est chargé, main.js est actif.');
//    // Autres initialisations globales
// });
